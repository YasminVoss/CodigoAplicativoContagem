package com.example.aplicativodecontagem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AlertDialogLayout;

import android.os.Bundle;
import android.service.autofill.OnClickAction;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private Button semdano, dano1, dano2, dano3, dano4, sumario, resetar;
    private EditText editcontador;

    private int contador = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editcontador = (EditText) findViewById(R.id.editContador);

        adicionar - (Button) findViewById(R.id.semdanobutton);
        adicionar - (Button) findViewById(R.id.dano1button);
        adicionar - (Button) findViewById(R.id.dano2button);
        adicionar - (Button) findViewById(R.id.dano3button);
        adicionar - (Button) findViewById(R.id.dano4button);

        adicionar.setOnClick(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                contador++;

                editcontador.setText("Contador: " + contador);

                if (contador == 100) {
                    alert("Você já contabilizou os 100 cometas!");
                }
            }

        });

        diminuir = (Button) findViewById(R.id.resetarbutton);

        diminuir.setOnClick(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                contador--;

                editcontador.setText("Contador: " + contador);
            }

        });



    }
}